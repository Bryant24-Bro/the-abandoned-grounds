THE ABANDONED GROUNDS
A simple original horror exploration game for iPhone browser.
Locations: abandoned school, abandoned house, abandoned playground.
Search the six clues. The creature begins hunting after clues are found.
Use the joystick to move, SEARCH near clues, and RUN to escape.
