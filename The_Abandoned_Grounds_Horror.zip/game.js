const c=document.getElementById('game'),x=c.getContext('2d');let W,H,run=false,last=0,keys={},stick={x:0,y:0},inter=false;const P={x:0,y:0,hp:100,spd:150,run:0};let monster,notes=[],found=0;
const areas=[
 {name:'SCHOOL',x:100,y:100,w:1100,h:700},
 {name:'HOUSE',x:1350,y:180,w:650,h:500},
 {name:'PLAYGROUND',x:1250,y:850,w:1050,h:650}];
function size(){W=innerWidth;H=innerHeight;c.width=W*devicePixelRatio;c.height=H*devicePixelRatio;x.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}addEventListener('resize',size);size();
function reset(){P.x=250;P.y=430;P.hp=100;P.run=0;found=0;notes=[{x:370,y:270,t:'A classroom is still warm...'}, {x:760,y:560,t:'The principal wrote: DO NOT GO HOME.'},{x:1570,y:380,t:'The front door locked by itself.'},{x:1750,y:520,t:'Something sleeps upstairs.'},{x:1510,y:1090,t:'The swings move when there is no wind.'},{x:1990,y:1280,t:'A small voice says your name.'}];monster={x:850,y:350,a:0,active:false}}
function area(){return areas.find(a=>P.x>a.x&&P.x<a.x+a.w&&P.y>a.y&&P.y<a.y+a.h)}
function update(dt){let dx=(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0),dy=(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0);if(stick.x||stick.y){dx=stick.x;dy=stick.y}let l=Math.hypot(dx,dy)||1;let sp=P.spd*(P.run>0?2.4:1);P.x=Math.max(40,Math.min(2250,P.x+dx/l*sp*dt));P.y=Math.max(40,Math.min(1480,P.y+dy/l*sp*dt));P.run-=dt;if(monster.active){let a=Math.atan2(P.y-monster.y,P.x-monster.x);monster.x+=Math.cos(a)*48*dt;monster.y+=Math.sin(a)*48*dt;if(Math.hypot(P.x-monster.x,P.y-monster.y)<30){P.hp-=24*dt;if(P.hp<=0){run=false;document.getElementById('msg').innerHTML='YOU NEVER LEFT<br><button onclick="start()">TRY AGAIN</button>'}}}}
function interact(){let n=notes.find(n=>!n.done&&Math.hypot(P.x-n.x,P.y-n.y)<60);if(n){n.done=true;found++;document.getElementById('msg').textContent=n.t;setTimeout(()=>document.getElementById('msg').textContent='',2400);if(found===2){monster.active=true;monster.x=1050;monster.y=650}if(found===4){monster.x=1900;monster.y=650}if(found===6){document.getElementById('msg').textContent='THE PLAYGROUND IS NOT EMPTY.';monster.active=true}}}
function draw(){x.clearRect(0,0,W,H);x.fillStyle='#0a0b0b';x.fillRect(0,0,2300,1500);for(const a of areas){x.fillStyle=a.name==='SCHOOL'?'#252322':a.name==='HOUSE'?'#29251f':'#16201b';x.fillRect(a.x,a.y,a.w,a.h);x.strokeStyle='#5b4c49';x.strokeRect(a.x,a.y,a.w,a.h);x.fillStyle='#aaa';x.font='24px system-ui';x.fillText(a.name,a.x+20,a.y+35)}
// school rooms
x.strokeStyle='#4b4440';for(let xx=180;xx<1100;xx+=230)x.strokeRect(xx,180,180,170);for(let xx=180;xx<1100;xx+=230)x.strokeRect(xx,410,180,170);
// house rooms
x.strokeRect(1400,250,250,180);x.strokeRect(1650,250,250,180);x.strokeRect(1400,430,500,180);
// playground equipment
for(let i=0;i<4;i++){x.strokeStyle='#66584c';x.beginPath();x.moveTo(1400+i*150,1000);x.lineTo(1400+i*150,1150);x.stroke();x.beginPath();x.moveTo(1370+i*150,1000);x.lineTo(1430+i*150,1000);x.stroke()}x.strokeStyle='#777';x.beginPath();x.arc(1950,1150,100,0,Math.PI*2);x.stroke();
// notes
for(const n of notes)if(!n.done){x.fillStyle='#c8b76c';x.fillRect(n.x-5,n.y-7,10,14)}
// monster
if(monster.active){x.fillStyle='#030303';x.beginPath();x.arc(monster.x,monster.y,24,0,7);x.fill();x.fillStyle='#b22';x.beginPath();x.arc(monster.x-7,monster.y-4,3,0,7);x.arc(monster.x+7,monster.y-4,3,0,7);x.fill()}
// player
x.fillStyle='#ddd';x.beginPath();x.arc(P.x,P.y,15,0,7);x.fill();
// camera-ish screen centered
let sx=Math.max(0,Math.min(2300-W,P.x-W/2)),sy=Math.max(0,Math.min(1500-H,P.y-H/2));let img=x.getImageData(sx,sy,W,H);x.clearRect(0,0,W,H);x.putImageData(img,0,0);
// darkness
let g=x.createRadialGradient(W/2,H/2,35,W/2,H/2,Math.min(W,H)*.58);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(.55,'rgba(0,0,0,.25)');g.addColorStop(1,'rgba(0,0,0,.88)');x.fillStyle=g;x.fillRect(0,0,W,H)}
function loop(t){let dt=Math.min(.033,(t-last)/1000||0);last=t;if(run){update(dt);draw();document.getElementById('place').textContent=area()?.name||'GROUNDS';document.getElementById('hp').style.width=Math.max(0,P.hp)*1.5+'px'}requestAnimationFrame(loop)}requestAnimationFrame(loop);
function start(){document.getElementById('start').style.display='none';run=true;reset()}document.getElementById('play').onclick=start;document.getElementById('interact').onclick=interact;document.getElementById('run').onclick=()=>P.run=.8;
const s=document.getElementById('stick'),k=s.querySelector('i');function move(e){let r=s.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,m=Math.min(42,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);stick={x:Math.cos(a)*m/42,y:Math.sin(a)*m/42};k.style.transform=`translate(${Math.cos(a)*m}px,${Math.sin(a)*m}px)`}s.onpointerdown=e=>{s.setPointerCapture(e.pointerId);move(e)};s.onpointermove=e=>{if(e.buttons)move(e)};s.onpointerup=()=>{stick={x:0,y:0};k.style.transform=''};addEventListener('keydown',e=>keys[e.key]=true);addEventListener('keyup',e=>keys[e.key]=false);